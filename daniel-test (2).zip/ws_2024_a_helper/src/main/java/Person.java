public class Person {
    private int line;
    private String id;
    private String firstName;
    private String lastName;
    private int year;
    private String gender;
    private String city;
    private int price;


    public Person(int line, String id, String firstName, String lastName, int year, String gender, String city, int price) {
        this.line = line;
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.year = year;
        this.gender = gender;
        this.city = city;
        this.price = price;
    }

    public int getLine() {
        return line;
    }

    public String getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getYear() {
        return year;
    }

    public String getGender() {
        return gender;
    }

    public String getCity() {
        return city;
    }

    public int getPrice() {
        return price;
    }
}
