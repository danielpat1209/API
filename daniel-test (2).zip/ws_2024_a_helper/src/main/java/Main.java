import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Map<Color,Integer> colors = new HashMap<>();
        Color color1 = null;
        try {
            BufferedImage image = ImageIO.read(new File("images/10.png"));
            for (int i = 0; i < image.getWidth(); i++) {
                for (int j = 0; j < image.getHeight(); j++) {
                    int color = image.getRGB(i, j);
                    color1 = new Color(color);
                    if (colors.containsKey(color1)){
                       int count = colors.get(color1)+1;
                       colors.put(color1,count);
                    }else {
                        colors.put(color1,1);
                    }
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        System.out.println(colors);
        List<Map.Entry<Color,Integer>> colorList= new ArrayList<>((colors.entrySet()));
        colorList.sort((k,v)-> k.getValue().compareTo(v.getValue()));
        System.out.println(colorList.get(0).getKey());
        System.out.println(colorList.get(3).getKey());
    }

    private static void getMax(List<Color> colors) {
        int max = 0;
        int count = 0;
        Color maxColor= null;
        for (int i = 0; i < colors.size(); i++) {
            Color first = colors.get(i);
            count = 0;
            for (int j = i+1; j < colors.size(); j++) {
                Color second = colors.get(j);
                if (first.getRed()==second.getRed()&&first.getBlue()==second.getBlue()&&first.getGreen()==second.getGreen()){
                    count++;
                }

            }
            if (count>max){
                max  =count;
                maxColor = first;
            }
            System.out.println("sjcn");
        }

        System.out.println(maxColor);
        
    }

    //כמה לקוחות מעיר שמתחילה במילה LAKE שילמו יותר מ400
    public static List<Person> readFile () {
        List<Person> lines = new ArrayList<>();
        try {
            File file = new File("data.csv");
            if (file.exists()) {
                Scanner scanner = new Scanner(file);
                while (scanner.hasNextLine()) {
                    String line = scanner.nextLine();
                    String[] tokens = line.split(",");
                    Person person = new Person(Integer.parseInt(tokens[0]),tokens[1],tokens[2],tokens[3],Integer.parseInt(tokens[4]),tokens[5],tokens[6],Integer.parseInt(tokens[7]));
                    lines.add(person);
                }

            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        return lines;
    }


}
